************************************************
*          [̲̅K][̲̅o][̲̅t][̲̅l][̲̅i][̲̅n][̲̅R][̲̅u][̲̅n][̲̅n][̲̅e][̲̅r]                *
*                                                                                            *
************************************************

This is a kotlin command tool. Run kotlin files with
a single command.

Prerequisities:
===================
1) Kotlin Compiler 
2) Jvm (Above 11.0v)



Set up :
===================
1.Open the bin folder
2.copy the path of the bin
3.add the path to the system envoirment variable



How to run
===================
1. Simply create a kotlin file and write the code
   inside it

2.Then open the command promt  in the root directory
3.Run the command as follow (runKt kotlinFileName.kt)


